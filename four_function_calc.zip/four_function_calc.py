#A python script that creates a simple calculator using the Tkinter library. The calculator can perform addition, subtraction, multiplication, and division. It also includes error handling for division by zero and invalid inputs.
import tkinter as tk
from tkinter import messagebox

#Define the four basic operations as functions
def add(x, y): return x + y
def subtract(x, y): return x - y
def multiply(x, y): return x * y
def divide(x, y):
    if y == 0:
        return "Error"
    return x / y

class CalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Calculator")
        self.root.geometry("300x400")
        
        #string variable that tracks what is shown on the display
        self.equation = tk.StringVar()
        
        #Display
        self.display = tk.Entry(root, textvariable=self.equation, font=("Arial", 20), borderwidth=5, relief="flat", justify='right')
        self.display.grid(row=0, column=0, columnspan=4, padx=10, pady=20, sticky="nsew")

        #Button Definitions
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            'C', '0', '=', '+'
        ]

        #Create and Place Buttons
        row_val = 1
        col_val = 0
        for button in buttons:
            action = lambda x=button: self.on_click(x)
            tk.Button(root, text=button, width=5, height=2, font=("Arial", 14),
                      command=action).grid(row=row_val, column=col_val, sticky="nsew", padx=2, pady=2)
            col_val += 1
            if col_val > 3:
                col_val = 0
                row_val += 1

        #Configure grid weights so buttons resize correctly
        for i in range(4):
            root.grid_columnconfigure(i, weight=1)
        for i in range(1, 5):
            root.grid_rowconfigure(i, weight=1)

    def on_click(self, char):
        if char == "=":
            try:
                # eval() handles the math based on the string in the entry box
                result = eval(self.equation.get())
                self.equation.set(result)
            except ZeroDivisionError:
                messagebox.showerror("Error", "Division by zero is not allowed.")
                self.equation.set("")
            except Exception:
                messagebox.showerror("Error", "Invalid Input")
                self.equation.set("")
        
        elif char == "C":
            self.equation.set("")
        
        else:
            # Add the button text to the current string
            current_text = self.equation.get()
            self.equation.set(current_text + str(char))

if __name__ == "__main__":
    root = tk.Tk()
    app = CalculatorApp(root)
    root.mainloop()
    
