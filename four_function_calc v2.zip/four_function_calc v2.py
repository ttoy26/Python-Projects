import tkinter as tk
from tkinter import messagebox
import math # Needed for square root

class CalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Calculator")
        self.root.geometry("400x550") # Slightly larger to fit new buttons
        
        self.memory = 0  # Initialize memory to 0
        self.equation = tk.StringVar()
        
        # Display
        self.display = tk.Entry(root, textvariable=self.equation, font=("Arial", 20), 
                                borderwidth=5, relief="flat", justify='right')
        self.display.grid(row=0, column=0, columnspan=4, padx=10, pady=20, sticky="nsew")

        # Updated Button Layout to include Memory and Powers
        buttons = [
            'MC', 'MR', 'M+', 'M-',
            'x²', '√', 'x^y', '/',
            '7', '8', '9', '*',
            '4', '5', '6', '-',
            '1', '2', '3', '+',
            'C', '0', '=', '.'
        ]

        row_val = 1
        col_val = 0
        for button in buttons:
            action = lambda x=button: self.on_click(x)
            tk.Button(root, text=button, width=5, height=2, font=("Arial", 12, "bold"),
                      command=action).grid(row=row_val, column=col_val, sticky="nsew", padx=2, pady=2)
            col_val += 1
            if col_val > 3:
                col_val = 0
                row_val += 1

        # Adjust grid weights
        for i in range(4):
            root.grid_columnconfigure(i, weight=1)
        for i in range(1, 7): # More rows now
            root.grid_rowconfigure(i, weight=1)

    def on_click(self, char):
        current_val = self.equation.get()

        try:
            # --- Memory Functions ---
            if char == "MC":
                self.memory = 0
            elif char == "MR":
                self.equation.set(self.memory)
            elif char == "M+":
                self.memory += float(eval(current_val)) if current_val else 0
            elif char == "M-":
                self.memory -= float(eval(current_val)) if current_val else 0

            # --- Power and Root Functions ---
            elif char == "x²":
                # Squares the current result
                result = float(eval(current_val)) ** 2
                self.equation.set(result)
            elif char == "√":
                # Square root of the current result
                result = math.sqrt(float(eval(current_val)))
                self.equation.set(result)
            elif char == "x^y":
                # Just adds the Python power operator to the string
                self.equation.set(current_val + "**")

            # --- Standard Functions ---
            elif char == "=":
                result = eval(current_val)
                self.equation.set(result)
            elif char == "C":
                self.equation.set("")
            else:
                self.equation.set(current_val + str(char))

        except ZeroDivisionError:
            messagebox.showerror("Error", "Division by zero is not allowed.")
            self.equation.set("")
        except Exception:
            messagebox.showerror("Error", "Invalid Input")
            self.equation.set("")

if __name__ == "__main__":
    root = tk.Tk()
    app = CalculatorApp(root)
    root.mainloop()
    
